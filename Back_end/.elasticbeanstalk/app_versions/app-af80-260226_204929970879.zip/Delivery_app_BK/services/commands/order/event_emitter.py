from typing import Iterable

from Delivery_app_BK.models import db, OrderEvent
from Delivery_app_BK.services.context import ServiceContext
from Delivery_app_BK.services.infra.events import get_event_bus


def emit_order_events(ctx: ServiceContext, events: Iterable[dict]) -> list[OrderEvent]:
    event_rows: list[OrderEvent] = []
    actor_id = ctx.user_id if ctx.user_id else None

    for event in events:
        order_id = event.get("order_id")
        event_name = event.get("event_name")
        if not order_id or not event_name:
            continue

        payload = event.get("payload")
        if not isinstance(payload, dict):
            payload = {}

        row = OrderEvent(
            order_id=order_id,
            event_name=event_name,
            payload=payload,
            actor_id=event.get("actor_id", actor_id),
            team_id=event.get("team_id", ctx.team_id),
        )
        db.session.add(row)
        event_rows.append(row)

    if not event_rows:
        return []

    db.session.flush()
    db.session.commit()

    if ctx.prevent_event_bus:
        return event_rows
    
    event_bus = get_event_bus()
    for event_row in event_rows:
        event_bus.publish(event_row)

    return event_rows
