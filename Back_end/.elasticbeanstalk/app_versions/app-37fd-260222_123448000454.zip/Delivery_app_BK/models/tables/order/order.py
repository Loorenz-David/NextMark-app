# Third-party dependecies

from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy import Index, text, JSON
from sqlalchemy.orm import relationship, validates
from sqlalchemy import Column, Integer, String, Boolean, ForeignKey

from datetime import datetime, timezone

# Local application imports
from Delivery_app_BK.models import db
from Delivery_app_BK.models.mixins.team_mixings.team_id import TeamScopedMixin
from Delivery_app_BK.models.utils import UTCDateTime
from Delivery_app_BK.models.mixins.validation_mixins.phone_number_validation import (
    PhoneNumberJSONValidationMixin
)
from Delivery_app_BK.models.mixins.validation_mixins.address_validation import (
    AddressJSONValidationMixin
)


# model definition of an order
class Order(
    db.Model,
    TeamScopedMixin,
    PhoneNumberJSONValidationMixin,
    AddressJSONValidationMixin
):
    __tablename__ = "order"

 
    id = Column(Integer, primary_key=True)
    client_id = Column(String, index=True)

    """
    must create a schema validator for the order_plan_objectives:
    the allowed values are the plan types table names. 
    """
    order_plan_objective= Column(String, index=True)

    reference_number = Column( String, index= True )
    external_order_id = Column( String, index = True )
    external_source = Column( String, index = True )

    tracking_number = Column( String, index = True )

    
    tracking_link = Column( String, index = True )
    client_first_name = Column(String, index=True)
    client_last_name = Column(String, index=True)
    client_email = Column(String, index=True)
    client_primary_phone = Column(JSONB().with_variant(JSON, "sqlite"))  
    client_secondary_phone = Column(JSONB().with_variant(JSON, "sqlite"))  
    client_address = Column(JSONB().with_variant(JSON, "sqlite"))  



    marketing_messages = Column(Boolean, default=False)

    earliest_delivery_date = Column(UTCDateTime, index=True) 
    latest_delivery_date = Column(UTCDateTime, index=True) 
    preferred_time_start = Column(String)  # "17:00"
    preferred_time_end   = Column(String)  # "20:00"

    creation_date = Column(UTCDateTime, default=lambda: datetime.now(timezone.utc))
    
    order_state_id = Column(
        Integer,
        ForeignKey("order_state.id", ondelete="SET NULL")
    )
    
    delivery_plan_id = Column(
        Integer, 
        ForeignKey("delivery_plan.id", ondelete="SET NULL"), 
    )

    archive_at = Column(UTCDateTime)
    
  

    # delivery_items has change to items, there is a lot of the fornt end that needs to be updated!
    items = db.relationship(
        "Item",
        back_populates="order",
        lazy="selectin",
        cascade="all, delete-orphan",
        passive_deletes=True
    )

    state = relationship(
        "OrderState",
        back_populates="order",
        lazy="selectin"
    )

    state_history = relationship(
        "OrderStateHistory",
        back_populates="order",
        lazy="selectin"
    )

    events = relationship(
        "OrderEvent",
        back_populates="order",
        lazy="selectin",
        cascade="all, delete-orphan",
        passive_deletes=True,
    )

    order_cases = relationship(
        "OrderCase",
        back_populates="order",
        lazy="selectin",
    )

    delivery_plan = relationship(
        "DeliveryPlan",
        back_populates = "orders" 
    )

    team = relationship(
        "Team",
        backref="orders",
    )

    __table_args__ = (
        # JSONB GIN indexes
        Index("ix_order_client_primary_phone_gin", client_primary_phone, postgresql_using="gin"),
        Index("ix_order_client_secondary_phone_gin", client_secondary_phone, postgresql_using="gin"),
        Index("ix_order_client_address_gin", client_address, postgresql_using="gin"),

        # Full-text index for partial string search
        Index(
            "ix_order_client_address_tsvector",
            text("to_tsvector('simple', client_address::text)"),
            postgresql_using="gin"
        ),
    )


    ORDER_PLAN_INTENTIONS = {
        "local_delivery",
        "international_shipping",
        "store_pickup",
    }

    @validates("order_plan_objective")
    def validate_order_plan_intention(self, key, value):
        if value is None:
            return value  # allow unset orders

        if value not in self.ORDER_PLAN_INTENTIONS:
            raise ValueError(
                f"Invalid order_plan_objective '{value}'. "
                f"Allowed values: {self.ORDER_PLAN_INTENTIONS}"
            )
        return value
